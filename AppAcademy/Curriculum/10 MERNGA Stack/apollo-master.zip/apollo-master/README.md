This is the main repository for discussion and coordination - the code will live elsewhere. Follow this repository for updates on the project!

- Check out the [homepage](http://www.apollographql.com/)
- Stay up to date by reading our [posts on Medium](https://blog.apollographql.com/)
- [Join us on Spectrum!](https://spectrum.chat/apollo)
