module.exports = {
  MONGO_URI: "mongodb+srv://TORTO21:pinners3@cluster00-ktmgw.mongodb.net/dogs_and_toys?retryWrites=true&w=majority"
};