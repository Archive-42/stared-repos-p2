module.exports = {
  MONGO_URI:
    'mongodb+srv://dev:gWzJJNEEAJ0pEuq1@cluster0-5axhu.mongodb.net/online_store?retryWrites=true&w=majority',
  secretOrKey: '6005bdbe-9232-11e9-bc42-526af7764f64',
  AWSKey: '93UZWNwMFB74LpF6DUL0O2TnHSEXyudI9vYoxVtL'
}
