module.exports = {
  MONGO_URI: "mongodb+srv://TORTO21:pinners3@cluster00-ktmgw.mongodb.net/online_store?retryWrites=true&w=majority",
  secretOrKey: "00faa625-8a64-4efd-91b5-4bac93685554",
  AWSKey: "RxaeMjQFCR4EumXWIARzJ7sjoXrFhXR27qF7HaYx"
};