import React from 'react'

const AddDomain = (props) => {
  return <div>Adding Domain...</div>
}

export default AddDomain