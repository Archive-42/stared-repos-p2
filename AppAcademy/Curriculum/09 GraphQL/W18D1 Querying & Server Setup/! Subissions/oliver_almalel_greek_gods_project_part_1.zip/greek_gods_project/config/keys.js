module.exports = {
  MONGO_URI: "mongodb+srv://TORTO21:pinners3@cluster00-ktmgw.mongodb.net/greek_gods?retryWrites=true&w=majority"
};