module.exports = {
  MONGO_URI:
    'mongodb+srv://dev:gWzJJNEEAJ0pEuq1@cluster0-5axhu.mongodb.net/greek_gods?retryWrites=true&w=majority'
}
