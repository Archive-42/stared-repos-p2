---
title: Apollo in your editor
description: How to configure the Apollo VSCode extension
---